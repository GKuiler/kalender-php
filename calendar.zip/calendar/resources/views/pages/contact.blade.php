@extends('main')

@section('content')

<h1>blade is working</h1>

@endsection