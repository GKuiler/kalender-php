@extends('main')

@section('content')

<form method="POST" action="{{ route('posts.update', $post->id) }}">
    {{ csrf_field() }}
    <div class="form-group">
        <label for="title">Name</label>
        <textarea type="text" class="form-control input-lg" id="person" name="person" rows="1" style="resize:none;">{{ $post->person }}</textarea>
    </div>
    <div class="form-group">
        <label for="title">Day</label>
        <textarea type="text" class="form-control input-lg" id="day" name="day" rows="1" style="resize:none;">{{ $post->day }}</textarea>
    </div>
    <div class="form-group">
        <label for="title">Month</label>
        <textarea type="text" class="form-control input-lg" id="month" name="month" rows="1" style="resize:none;">{{ $post->month }}</textarea>
    </div>
    <div class="form-group">
        <label for="title">year</label>
        <textarea type="text" class="form-control input-lg" id="year" name="year" rows="1" style="resize:none;">{{ $post->year }}</textarea>
    </div>
            
    <!--<div class="col-md-4">
      	<div class="well">
        	<div class="row">
        		<div class="col-sm-6">
        			<a href="{{ route('posts.show', $post->id) }}" class="btn btn-danger btn-block">Back</a>
    			</div>
    		</div>
    	</div>    				
   	</div>-->	
   	<hr>
    <div class="col-sm-6">
	    <button type="submit" class="btn btn-success btn-block">Save</button>
	    <input type="hidden" name="_token" value="{{ Session::token() }}">
	    {{ method_field('PUT') }}
	</div>
    
</form>﻿
 

@endsection