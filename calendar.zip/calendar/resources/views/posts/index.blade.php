@extends('main')

@section('content')

	<div class="row">
		<div class="col-md-8">
			<h1>Calendar</h1>
		</div>
		<div class="col-md-4">
			<a href="{{ route('posts.create') }}" class="btn btn-lg btn-block btn-primary">Verjaardagen Toevoegen</a>
		</div>
		<hr>
		<div class="row">
			<div class="col-md-12">
				<table class="table">
					<thead>
						<th>Verjaardagen</th>

					</thead>

					<tbody>
						
						@foreach ($posts as $post)

							@if ($post->month != $curMonth)
							
								@php

									$curMonth = $post->month;

								@endphp
								<tr>
									<th>{{ $months[$curMonth] }}</th>
								</tr>
									
								
							@endif
							<tr>
							@if ($post->day != $curDay)
								@php
									$curDay = $post->day;
								@endphp
								
									<td>{{ $post->person }}</td>
									<td>{{ $post->day }}</td>
									<td>{{ $post->year }}</td>
								<td>	
									<a href="{{ route('posts.edit', $post->id) }}" class="btn btn-default btn-block">Edit</a> 
									<form method="POST" action="{{ route('posts.destroy', $post->id) }}">
									    <input type="submit" value="Delete" class="btn btn-danger btn-block">
									    <input type="hidden" name="_token" value="{{ Session::token() }}">
									   	{{ method_field('DELETE') }}
									</form>﻿	
								</td>
							</tr>
							@endif

						@endforeach
					</tbody>
				</table>
			</div>
		</div>		
	</div>

@endsection