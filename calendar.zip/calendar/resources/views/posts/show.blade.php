@extends('main')

@section('content')
	
	<h1>Succesfull</h1>


@endsection