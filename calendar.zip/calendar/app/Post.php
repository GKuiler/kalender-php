<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Post extends Model
{
    //
    protected $fillable = ['person', 'day', 'month', 'year'];
    protected $table = 'post';
    public $timestamps = false;
}
