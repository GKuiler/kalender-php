<?php $__env->startSection('content'); ?>

<form method="POST" action="<?php echo e(route('posts.update', $post->id)); ?>">
    <?php echo e(csrf_field()); ?>

    <div class="form-group">
        <label for="title">Name</label>
        <textarea type="text" class="form-control input-lg" id="person" name="person" rows="1" style="resize:none;"><?php echo e($post->person); ?></textarea>
    </div>
    <div class="form-group">
        <label for="title">Day</label>
        <textarea type="text" class="form-control input-lg" id="day" name="day" rows="1" style="resize:none;"><?php echo e($post->day); ?></textarea>
    </div>
    <div class="form-group">
        <label for="title">Month</label>
        <textarea type="text" class="form-control input-lg" id="month" name="month" rows="1" style="resize:none;"><?php echo e($post->month); ?></textarea>
    </div>
    <div class="form-group">
        <label for="title">year</label>
        <textarea type="text" class="form-control input-lg" id="year" name="year" rows="1" style="resize:none;"><?php echo e($post->year); ?></textarea>
    </div>
            
    <!--<div class="col-md-4">
      	<div class="well">
        	<div class="row">
        		<div class="col-sm-6">
        			<a href="<?php echo e(route('posts.show', $post->id)); ?>" class="btn btn-danger btn-block">Back</a>
    			</div>
    		</div>
    	</div>    				
   	</div>-->	
   	<hr>
    <div class="col-sm-6">
	    <button type="submit" class="btn btn-success btn-block">Save</button>
	    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
	    <?php echo e(method_field('PUT')); ?>

	</div>
    
</form>﻿
 

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>