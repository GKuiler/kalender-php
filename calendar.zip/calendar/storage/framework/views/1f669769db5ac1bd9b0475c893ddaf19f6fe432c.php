<?php $__env->startSection('content'); ?>
	<div class="row">
	  <div class="col-md-6 col-md-offset-2">
	    <h1>Verjaardag toevoegen</h1>
	    <hr>
	    <form method="POST" action="<?php echo e(route('posts.store')); ?>">
	    	<?php echo e(csrf_field()); ?>

	      <div class="form-group">
	        <label name="title">Naam</label>
	        <input id="title" name="person" class="form-control">
	        <label name="title">Dag</label>
	        <input id="title" name="day" class="form-control">
	        <label name="title">Maand</label>
	        <input id="title" name="month" class="form-control">
	        <label name="title">Jaar</label>
	        <input id="title" name="year" class="form-control">
	      </div>
	      <input type="submit" value="Voeg toe" class="btn btn-success btn-lg btn-block">
	      <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
	    </form>
	  </div>
	</div>﻿
<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>