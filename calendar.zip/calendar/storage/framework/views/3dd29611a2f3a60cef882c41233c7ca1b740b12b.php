<?php $__env->startSection('content'); ?>

	<div class="row">
		<div class="col-md-8">
			<h1>Calendar</h1>
		</div>
		<div class="col-md-4">
			<a href="<?php echo e(route('posts.create')); ?>" class="btn btn-lg btn-block btn-primary">Verjaardagen Toevoegen</a>
		</div>
		<hr>
		<div class="row">
			<div class="col-md-12">
				<table class="table">
					<thead>
						<th>Verjaardagen</th>

					</thead>

					<tbody>
						
						<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

							<?php if($post->month != $curMonth): ?>
							
								<?php

									$curMonth = $post->month;

								?>
								<tr>
									<th><?php echo e($months[$curMonth]); ?></th>
								</tr>
									
								
							<?php endif; ?>
							<tr>
							<?php if($post->day != $curDay): ?>
								<?php
									$curDay = $post->day;
								?>
								
									<td><?php echo e($post->person); ?></td>
									<td><?php echo e($post->day); ?></td>
									<td><?php echo e($post->year); ?></td>
								<td>	
									<a href="<?php echo e(route('posts.edit', $post->id)); ?>" class="btn btn-default btn-block">Edit</a> 
									<form method="POST" action="<?php echo e(route('posts.destroy', $post->id)); ?>">
									    <input type="submit" value="Delete" class="btn btn-danger btn-block">
									    <input type="hidden" name="_token" value="<?php echo e(Session::token()); ?>">
									   	<?php echo e(method_field('DELETE')); ?>

									</form>﻿	
								</td>
							</tr>
							<?php endif; ?>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>
			</div>
		</div>		
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>